#include <stdio.h>

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"

void printcchar(char *color,char c)
{
	printf("%s%c",color,c);
	printf("%s",KNRM);
}

int main()
{
    int i, j;
    char field[10][10];
    for(i=0;i<8;i++)
    {
    	for(j=0;j<8;j++)
    	{
    		field[i][j]='*';
    		if(i==0)
    			PrintColorChar(KNRM,field[i][j]);
    		else if(i==1)
    			PrintColorChar(KRED,field[i][j]);
    		else if(i==2)
    			PrintColorChar(KGRN,field[i][j]);
    		else if(i==3)
    			PrintColorChar(KYEL,field[i][j]);
    		else if(i==4)
    			PrintColorChar(KBLU,field[i][j]);
    		else if(i==5)
    			PrintColorChar(KMAG,field[i][j]);
    		else if(i==6)
    			PrintColorChar(KCYN,field[i][j]);
    		else
    			PrintColorChar(KWHT,field[i][j]);
    		
    	}
    	printf("\n");
    }
    

    return 0;
}
