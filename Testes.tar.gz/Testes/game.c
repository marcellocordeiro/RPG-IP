#include <stdio.h>
#include <stdlib.h>
#include "client.h"
#include "server.h"
#include "default.h"
#include "game.h"

void printcchar(char *color,char c)
{
	printf("%s%c",color,c);
	printf("%s",KNRM);
}

void draw(MOB hero,MAP f,MOB monster)
{
	int i, j;
	for(i=0;i<7;i++)
		printcchar(KNRM,'*');
		printf("\n");
	for( i = hero.x - 2; i < hero.x + 3; i++)
	{
		printcchar(KNRM,'*');
		for( j = hero.y - 2; j < hero.y + 3; j++)
		{
			if((i < 0) || (j < 0) || (i >= f.linha) || (j >= f.coluna))
				printcchar(KGRN,'*');
			else if(i == hero.x && j == hero.y)
				printcchar(hero.color,hero.sprite);
			else if(i == monster.x && j == monster.y && monster.isAlive)
				printcchar(monster.color,monster.sprite);
			else if(f.mapa[i][j]=='+')
				printcchar(KRED,f.mapa[i][j]);
			else
				printcchar(KGRN,f.mapa[i][j]);
		}
		printcchar(KNRM,'*');
		printf("\n");
	}
	for(i=0;i<7;i++)
		printcchar(KNRM,'*');
	printf("\n%sHP: %d/%d%s\n",KRED,hero.HP_CUR,hero.HP_TOT,KNRM);
}

void input(MOB *hero)//OK
{
	char in;
	in=getch();
	switch(in)
	{
		case UP:
			hero->button = UP;
			break;
		case DOWN:
			hero->button = DOWN;
			break;
		case LEFT:
			hero->button = LEFT;
			break;
		case RIGHT:
			hero->button = RIGHT;
			break;
		case QUIT:
			hero->button = QUIT;
			break;
		default:
			hero->button = '\0';
			break;
	}
}


void logic(MOB *hero,MAP *f, MOB monster,int *gameover,int *inbattle)
{
	int temp;
	switch(hero->button)
	{
		case UP:
			if(hero->sprite != '^')
				hero->sprite = '^';
			else
			{
				temp = hero->x - 1;
				if( f->mapa[temp][hero->y] == '+')
				{
					hero->x = temp;
					f->mapa[hero->x][hero->y]=' ';
					hero->HP_CUR+=10;
					if(hero->HP_CUR > hero->HP_TOT)
						hero->HP_CUR = hero->HP_TOT;
				}
				else if( f->mapa[temp][hero->y] != '*')
					hero->x = temp;
			}
			break;
			
		case DOWN:
			if(hero->sprite != 'v')
				hero->sprite = 'v';
			else
			{
				temp = hero->x + 1;
				if( f->mapa[temp][hero->y] == '+')
				{
					hero->x = temp;
					f->mapa[hero->x][hero->y]=' ';
					hero->HP_CUR+=10;
					if(hero->HP_CUR > hero->HP_TOT)
						hero->HP_CUR = hero->HP_TOT;
				}
				else if( f->mapa[temp][hero->y] != '*')
					hero->x = temp;
			}
			break;
			
		case LEFT:
			if(hero->sprite != '<')
				hero->sprite = '<';
			else
			{
				temp = hero->y - 1;
				if( f->mapa[hero->x][temp] == '+')
				{
					hero->y = temp;
					f->mapa[hero->x][hero->y]=' ';
					hero->HP_CUR+=10;
					if(hero->HP_CUR > hero->HP_TOT)
						hero->HP_CUR = hero->HP_TOT;
				}
				else if( f->mapa[hero->x][temp] != '*')
					hero->y = temp;
			}
			break;
			
		case RIGHT:
			if(hero->sprite != '>')
				hero->sprite = '>';
			else
			{
				temp = hero->y + 1;
				if( f->mapa[hero->x][temp] == '+')
				{
					hero->y = temp;
					f->mapa[hero->x][hero->y]=' ';
					hero->HP_CUR+=10;
					if(hero->HP_CUR > hero->HP_TOT)
						hero->HP_CUR = hero->HP_TOT;
				}
				else if( f->mapa[hero->x][temp] != '*')
					hero->y = temp;
			}
			break;
		
		case QUIT:
			*gameover=1;
			break;
	}
	if((hero->x == monster.x) && (hero->y == monster.y))
		*inbattle=1;
}

void drawall(MOB hero,MAP f,MOB monster)
{
	int i, j;
	for( i = 0; i < f.linha; i++)
	{
		for( j = 0; j < f.coluna; j++)
		{
			if((i < 0) || (j < 0) || (i >= f.linha) || (j >= f.coluna))
				printcchar(KGRN,'*');
			else if(i == hero.x && j == hero.y)
				printcchar(hero.color,hero.sprite);
			else if(i == monster.x && j == monster.y)
				printcchar(monster.color,monster.sprite);
			else if(f.mapa[i][j]=='+')
				printcchar(KRED,f.mapa[i][j]);
			else
				printcchar(KGRN,f.mapa[i][j]);
		}
		printf("\n");
	}
	printf("\n%sHP: %d/%d%s\n",KRED,hero.HP_CUR,hero.HP_TOT,KNRM);
}

void printbattle(MAP f)
{
	int i, j;
	for( i = 0; i < f.linha; i++)
	{
		for( j = 0; j < f.coluna; j++)
			printf("%c",f.mapa[i][j]);
		printf("\n");
	}
}








