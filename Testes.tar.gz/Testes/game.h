#ifndef GAME_H
#define GAME_H

#define UP '5'
#define DOWN '2'
#define LEFT '1'
#define RIGHT '3'
#define QUIT 'q'

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"


typedef struct
{
	char sprite;
	char *color;
	char button;
	int x;
	int y;
	int HP_CUR;
	int HP_TOT;
	int ATK;
	int DEF;
	int isAlive;
}MOB;

typedef struct
{
	int linha;
	int coluna;
	char **mapa;
}MAP;

void printcchar(char *color,char c);
void draw(MOB hero,MAP f,MOB monster);
void input(MOB *hero);
void logic(MOB *hero,MAP *f, MOB monster,int *gameover,int *inbattle);
void drawall(MOB hero,MAP f,MOB monster);
void printbattle(MAP f);



#endif
