#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "client.h"
#include "server.h"
#include "default.h"
#include "game.h"

int main()
{
	//VARIAVEIS
	FILE *fp;
	FILE *fp2;
	MAP field;
	MAP battleframe;
	MOB player;
	MOB *monster;
	int i;
	int gameover = 0;
	int inbattle = 0;
	int flag=0;
	
	
	//RAND
	srand(time(NULL));
	
	//LEITURA DO ARQUIVO - INICIALIZAÇÃO DA VARIAVEL FIELD.
	fp = fopen("TESTinput.txt","rt");
	if(fp == NULL)
	{
		printf("ERRO: ARQUIVO N ENCONTRADO.\n");
		exit(1);
	}
	fscanf(fp,"%d %d",&field.linha,&field.coluna);
	field.mapa = (char**) malloc(field.linha*sizeof(char*));
	for( i = 0; i < field.linha; i++)
		field.mapa[i] = (char*) malloc((field.coluna + 1)*sizeof(char));
	
	for( i = 0; i < field.linha; i++)
		fscanf(fp, " %[^\n]", field.mapa[i]);
		
	//LEITURA DO ARQUIVO - INICIALIZANDO BATTLEFRAME	
	fp2 = fopen("battle.txt","rt");
	if(fp2 == NULL)
	{
		printf("ERRO: ARQUIVO N ENCONTRADO.\n");
		exit(1);
	}
	fscanf(fp2, "%d %d", &battleframe.linha, &battleframe.coluna);
	battleframe.mapa = (char**) malloc(battleframe.linha*sizeof(char*));
	for( i = 0; i < battleframe.linha; i++)
		battleframe.mapa[i] = (char*) malloc((battleframe.coluna + 1)*sizeof(char));
	for( i = 0; i < battleframe.linha; i++)
		fscanf(fp2, " %[^\n]", battleframe.mapa[i]);
		
	//INICIALIZAÇAO DA VARIAVEL PLAYER.
	player.sprite = '^';
	player.color = KBLU;
	player.x = 1;
	player.y = 1;
	player.HP_TOT = 100;
	player.HP_CUR = 70;
	player.ATK = 20;
	player.DEF = 10;
	player.isAlive=1;
	player.button = '\0';
		
	//INICIALIZAÇAO DA VARIAVEL MONSTRO.
	monster = (MOB*) malloc(sizeof(MOB));
	monster[0].sprite = 'M';
	monster[0].color = KYEL;
	monster[0].HP_TOT = 100;
	monster[0].HP_CUR = 100;
	monster[0].ATK = 15;
	monster[0].DEF = 5;
	monster[0].isAlive=1;
	do
	{
		flag=0;
		monster[0].x=rand()%(field.linha - 1) + 1;
		monster[0].y=rand()%(field.coluna - 1) + 1;
		if(field.mapa[monster[0].x][monster[0].y] == '*')
			flag=1;
		else if(field.mapa[monster[0].x][monster[0].y] == '+')
			flag=1;
		else if((monster[0].x == player.x) && (monster[0].y == player.y))
			flag=1;
	}while(flag);
	
	
	//LOGICA
	while(!gameover)
	{
		drawall(player,field,monster[0]);
		input(&player);
		logic(&player,&field,monster[0],&gameover,&inbattle);
		while(inbattle)
		{
			system("clear");
			printbattle(battleframe);	
			inbattle = 0;
			scanf("%d",&i);
			gameover=1;
		}
		system("clear");
	}
	//END
	
	fclose(fp);
	fclose(fp2);
	free(monster);
	for( i = 0; i < field.linha; i++)
		free(field.mapa[i]);
	free(field.mapa);
	return 0;
}
